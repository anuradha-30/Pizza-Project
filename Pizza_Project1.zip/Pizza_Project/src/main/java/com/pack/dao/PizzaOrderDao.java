package com.pack.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import com.pack.model.Customer;
import com.pack.model.LoginUser;
import com.pack.model.Pizzaorder;
public class PizzaOrderDao {
	@Autowired
	private	 SessionFactory sessionFactory;
	 
	
	public int placeOrder(Customer customer,Pizzaorder pizza) {
		Session session=this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		System.out.println("session "+session);
		pizza.setCustomerid(customer);
		session.save(pizza);
		int pid=pizza.getOrderid();
		System.out.println("pid "+pid);
		tx.commit();
		session.close();
		return pid;
		
	}
	public String validate(LoginUser user) {
		   
		 Session session=sessionFactory.openSession();
		  Transaction tx=session.beginTransaction();
		  
		  session.save(user);
		  //tx.commit();
		  session.close(); 
	 user = null;

		String hql = "from LoginUser as u where u.username=:name and u.password=:pwd";
		Query query = session.createQuery(hql);
		query.setParameter("name", user.getUsername());
		query.setParameter("pwd", user.getPassword());
		List list=query.getResultList();
		if(list.size()==0) 
			return "failure";
			else
				return "success";
		
			
}
}
