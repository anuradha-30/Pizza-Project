package com.pack.service;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.pack.model.Customer;
import com.pack.model.LoginUser;
import com.pack.model.Pizzaorder;

import com.pack.dao.PizzaOrderDao;
public class PizzaOrderService {
@Autowired
private PizzaOrderDao pizzaDao;

@Autowired
private	 SessionFactory sessionFactory;

@Autowired
private SessionFactory pizzaOrder;

public int placeOrder(Customer customer,Pizzaorder pizza, int pTopping) {
	int totalPrice=0;
	totalPrice=350+pTopping;
	pizza.setTotalprice(totalPrice);
	int k=pizzaDao.placeOrder(customer,pizza);
	return k;
	
}
public void login(LoginUser user) {
	  pizzaDao.validate(user);  
	
}
public void homepage(Pizzaorder order) {
pizzaDao.placeOrder(order);
}
}
